'''
Author: wangjin
Date: 2022-06-01 16:49:11
LastEditors: wangjin
LastEditTime: 2022-06-14 14:14:38
Description: 
'''

import loguru
import time
from Ctrip_port.tools.common_cralwer_tools import Database_tools as db
from Ctrip_port import Ctrip_options
# import Ctrip_options
import json
options = Ctrip_options.Options_class()


def Logger_info(state,data,tb_name="Log_all",SQL_CONF=options.LOG_SQL_CONF,task_name = options.TaskName):
    '''
    description: 存储日志通用函数，数据会不分格式整体存到数据库
    调用此参数会输出日志 参数看函数 state True=SUCCESS Flase=ERROE "INFO"=INFO
    return {*}
    '''
    # DATA_DICT 模版
    DATA_DICT = {
        "task_name": task_name,  # 任务名称，标记一整个任务进程的名称
        "state": state,
        "data": data,  # 成功记录数据，失败记录错误
    }
    if DATA_DICT["state"]:
        DATA_DICT["state"] = "SUCCESS"
        loguru.logger.success("任务:"+DATA_DICT["task_name"]+"\n"+DATA_DICT["data"])
    if DATA_DICT["state"] is False:
        DATA_DICT["state"] = "ERROR"
        loguru.logger.error("任务:"+DATA_DICT["task_name"]+"\n"+DATA_DICT["data"])
    if DATA_DICT["state"] == "INFO":
        loguru.logger.info("任务:"+DATA_DICT["task_name"]+"\n"+DATA_DICT["data"])

    sql = db.insert_data_format_sql(tb_name, DATA_DICT)
    db.insert_SQL(SQL_CONF=SQL_CONF, sql=sql)


def Logger_price(HotelData_Dict,tb_name="Log_price",SQL_CONF=options.LOG_SQL_CONF,task_name = options.TaskName,channal="Ctrip"):
    '''
    HotelData_Dict = {"hotelId": "5983302", "cralwerTime": "2022-06-08 15:50:41", "roomsData": [{"baseRoomId": 25427750, "roomName": "大床房", "saleCards": [{"ubt_roomid": 137260147, "price": 101, "breakfast": 0, "roomStatue": 0}, {"ubt_roomid": 892519517, "price": 83, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 25427748, "roomName": "标准间", "saleCards": [{"ubt_roomid": 137259966, "price": 108, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 26069783, "roomName": "主题房", "saleCards": [{"ubt_roomid": 137260055, "price": 124, "breakfast": 0, "roomStatue": 0}, {"ubt_roomid": 826044895, "price": 95, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 25427752, "roomName": "棋牌房", "saleCards": [{"ubt_roomid": 966042897, "price": 132, "breakfast": 0, "roomStatue": 0}]}]}
    '''
    hotelId = HotelData_Dict["hotelId"]
    masterHotelName = HotelData_Dict["masterHotelName"]
    for roomsData in HotelData_Dict["roomsData"]:
        baseRoomId = roomsData["baseRoomId"]
        roomName = roomsData["roomName"]
        for saleCard in roomsData["saleCards"]:
            SQL_DICT = {}
            SQL_DICT["ubt_roomid"] = saleCard["ubt_roomid"]
            SQL_DICT["price"] = saleCard["price"]
            SQL_DICT["breakfast"] = saleCard["breakfast"]
            SQL_DICT["roomStatue"] = saleCard["roomStatue"]
            try:SQL_DICT["If_show"] = saleCard["If_show"]
            except:pass
            try:SQL_DICT["Gap_price"] = saleCard["Gap_price"]
            except:pass
            SQL_DICT["roomName"] = roomName
            SQL_DICT["baseRoomId"] = baseRoomId
            SQL_DICT["hotelId"] = hotelId
            SQL_DICT["masterHotelName"] = masterHotelName
            #TODO 频道修改此处
            SQL_DICT["channal"] = channal
            SQL_DICT["task_name"] = task_name
            sql = db.insert_data_format_sql(tb_name,SQL_DICT)
            db.insert_SQL(SQL_CONF=SQL_CONF,sql=sql)
    if (HotelData_Dict["unshow"] != []):
        for saleCard in HotelData_Dict["unshow"]:
            SQL_DICT = {}
            SQL_DICT["hotelId"] = hotelId
            SQL_DICT["masterHotelName"] = masterHotelName
            SQL_DICT["ubt_roomid"] = saleCard["ubt_roomid"]
            SQL_DICT["If_show"] = saleCard["If_show"]
            #TODO 频道修改此处
            SQL_DICT["channal"] = channal
            SQL_DICT["task_name"] = task_name
            sql = db.insert_data_format_sql(tb_name,SQL_DICT)
            db.insert_SQL(SQL_CONF=SQL_CONF,sql=sql)

def Logger_lowest_price(price_post_dict,tb_name="Log_lowest_price",SQL_CONF=options.LOG_SQL_CONF,task_name = options.TaskName,channal="Ctrip"):
    '''
    {"masterHotelId": "6299765", "roomInfos": [{"masterRoomId": 45005947, "lowestPrice": 158, "roomStatue": 0, "breakfastNum": 0}, {"masterRoomId": 304636215, "lowestPrice": 167, "roomStatue": 0, "breakfastNum": 0}, {"masterRoomId": 45005948, "lowestPrice": 185, "roomStatue": 0, "breakfastNum": 0}, {"masterRoomId": 28654143, "lowestPrice": 194, "roomStatue": 0, "breakfastNum": 0}, {"masterRoomId": 77032768, "lowestPrice": 213, "roomStatue": 0, "breakfastNum": 0}, {"masterRoomId": 304394966, "lowestPrice": 198, "roomStatue": 1, "breakfastNum": 0}, {"masterRoomId": 28654142, "lowestPrice": 188, "roomStatue": 1, "breakfastNum": 0}], "showInfos": []}
    '''
    price_post_dict['cralwerTime'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    price_post_dict['cralwerDate'] = time.strftime("%Y-%m-%d", time.localtime())
    hotelId = price_post_dict["masterHotelId"]
    for roomsData in price_post_dict["roomInfos"]:
        sql_dict = {}
        sql_dict['masterHotelId'] = int(hotelId)
        sql_dict['masterRoomId'] = roomsData["masterRoomId"]
        sql_dict['lowestPrice'] = roomsData["lowestPrice"]
        sql_dict['roomStatue'] = roomsData["roomStatue"]
        sql_dict['breakfastNum'] = roomsData["breakfastNum"]
        sql_dict['cralwerTime'] = price_post_dict['cralwerTime']
        sql_dict['cralwerDate'] = price_post_dict['cralwerDate']
        sql_dict["channal"] = channal
        sql_dict["task_name"] = task_name
        sql = db.insert_data_format_sql(tb_name,sql_dict)
        db.insert_SQL(SQL_CONF=SQL_CONF,sql=sql)
def Logger_show(HotelData_Dict,tb_name="Log_show",SQL_CONF=options.LOG_SQL_CONF,task_name = options.TaskName,channal="Ctrip"):
    '''
    {"masterHotelId": "5983302", "data": [{"roomId": 1232659432, "ifShow": 2, "showPrice": 100}, {"roomId": 1232659439, "ifShow": 2, "showPrice": 106}, {"roomId": 1232659443, "ifShow": 2, "showPrice": 121}, {"roomId": 1232659445, "ifShow": 2, "showPrice": 132}]}
    '''
    hotelId = HotelData_Dict["masterHotelId"]
    if("masterHotelName" in HotelData_Dict): 
        masterHotelName = HotelData_Dict["masterHotelName"]
    for roomsData in HotelData_Dict["data"]:
        roomId = roomsData["roomId"]
        ifShow = roomsData["ifShow"]
        if("showPrice" in roomsData):
            showPrice = roomsData["showPrice"]
        SQL_DICT = {}
        SQL_DICT["showPrice"] = showPrice
        SQL_DICT["hotelId"] = hotelId
        # SQL_DICT["masterHotelName"] = masterHotelName
        SQL_DICT["ubt_roomid"] = roomId
        SQL_DICT["ifShow"] = ifShow

        SQL_DICT["channal"] = channal
        SQL_DICT["task_name"] = task_name
        sql = db.insert_data_format_sql(tb_name,SQL_DICT)
        db.insert_SQL(SQL_CONF=SQL_CONF,sql=sql)
        
        









if __name__ == '__main__':
    # DATA_DICT = {
    #     "task_name":"测试",#任务名称，标记一整个任务进程的名称
    #     "state":"SUCCESS",#SUCCESS ERROR
    #     "data":"测试",#成功记录数据，失败记录错误
    # }
    # Logger_info(DATA_DICT)
    # HotelData_Dict = {"masterHotelName":"测试酒店","hotelId": "5983302", "cralwerTime": "2022-06-08 15:50:41", "roomsData": [{"baseRoomId": 25427750, "roomName": "大床房", "saleCards": [{"ubt_roomid": 137260147, "price": 101, "breakfast": 0, "roomStatue": 0}, {"ubt_roomid": 892519517, "price": 83, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 25427748, "roomName": "标准间", "saleCards": [{"ubt_roomid": 137259966, "price": 108, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 26069783, "roomName": "主题房", "saleCards": [{"ubt_roomid": 137260055, "price": 124, "breakfast": 0, "roomStatue": 0}, {"ubt_roomid": 826044895, "price": 95, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 25427752, "roomName": "棋牌房", "saleCards": [{"ubt_roomid": 966042897, "price": 132, "breakfast": 0, "roomStatue": 0}]}]}
    
    # Logger_price(HotelData_Dict=HotelData_Dict):
    show = {"masterHotelId": "5983302", "data": [{"roomId": 1232659432, "ifShow": 2, "showPrice": 100}, {"roomId": 1232659439, "ifShow": 2, "showPrice": 106}, {"roomId": 1232659443, "ifShow": 2, "showPrice": 121}, {"roomId": 1232659445, "ifShow": 2, "showPrice": 132}]}
    Logger_show(HotelData_Dict=json.dumps)
    




    



