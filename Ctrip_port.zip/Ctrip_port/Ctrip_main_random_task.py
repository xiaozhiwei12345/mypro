# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:Ctrip_main_random_task.py
@Date:2022/8/12
"""

import requests
import time
import redis
import loguru
import json
from apscheduler.schedulers.blocking import BlockingScheduler

REDIS_KEY = "Ctrip_hotel_tasks"


class CtripTask():
    def __init__(self):
        self.redis_cli = redis.StrictRedis(
            host="redis1.whalepms.com",
            port=6379,
            password="zUy0piREyUo",
            decode_responses=True
        )

    def add_task(self):
        # 获取要爬得酒店任务，后端接口拉取数据
        res_data = requests.get("http://ota.inner.whalepms.com:83/ota/getHotelInfos").text
        hotel_task_json = json.loads(res_data)
        loguru.logger.info("总酒店数为:" + str(len(hotel_task_json)))
        for one_hotel_task in hotel_task_json:
            loguru.logger.info(one_hotel_task)
            self.redis_cli.rpush(REDIS_KEY, json.dumps(one_hotel_task, ensure_ascii=False))
        loguru.logger.info("任务添加完成")





    def Monitor(self):
        scheduler = BlockingScheduler()
        scheduler.add_job(self.add_task, "cron", hour=9, minute=10)
        scheduler.add_job(self.add_task, "cron", hour=10, minute=10)
        scheduler.add_job(self.add_task, "cron", hour=12, minute=10)
        scheduler.add_job(self.add_task, "cron", hour=14, minute=10)
        scheduler.add_job(self.add_task, "cron", hour=16, minute=10)
        scheduler.add_job(self.add_task, "cron", hour=18, minute=10)
        scheduler.add_job(self.add_task, "cron", hour=19, minute=30)
        scheduler.add_job(self.add_task, "cron", hour=21, minute=10)
        scheduler.start()


if __name__ == '__main__':
    ctrip = CtripTask()
    ctrip.add_task()
    # ctrip.Monitor()


