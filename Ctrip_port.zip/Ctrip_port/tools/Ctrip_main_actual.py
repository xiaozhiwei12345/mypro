
'''
Author: wangjin
Date: 2022-06-06 17:21:15
LastEditors: wangjin
LastEditTime: 2022-07-04 11:19:17
Description: 即时爬取redis队列中的任务
'''
from function import Ctrip_page_func
from function import Ctrip_sql_func
from tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options 
import requests
import time
import loguru
import json
from log_func import log_fun
class Ctrip():
    group_id = 1
    def Batch(self):
        
        option = Ctrip_options.Options_class()
        while(True):
            try:
                Hotel_dict = Ctrip_sql_func.Get_hotel_json_redis_contab(option.Redis_host_pub,option.Get_HotelPrice_ids_task)
            except:
                loguru.logger.info("列表暂无信息")
                cooling_time = 5# 访问时间修改这里,方式携程大数据风控
                loguru.logger.info("等待时间："+str(cooling_time))
                time.sleep(cooling_time)
                continue
            Login_Option = Ctrip_sql_func.Get_usable_login_option(option.DATA_SQL_CONF,If_random=True,group_id=self.group_id)
            if(Login_Option == None):#无可用账号时，跳出
                break
            #获取ip
            ip = self.Get_ip()
            #如果
            if(Login_Option["duid"] == "0" or Login_Option["ticket"] == "0"):
                #如果duid或ticket为空说明账号未初始化，请求接口获取字端
                try:
                    Login_Option = self.Formate_account(Login_Option,ip,option)
                except:
                    Ctrip_sql_func.push_hotel_json_redis_contab(option.Redis_host_pub,option.Get_HotelPrice_ids_task,Hotel_dict)
                    loguru.logger.error("IP失效，重新更换")
                    continue

            loguru.logger.success("待爬取:"+json.dumps(Hotel_dict, ensure_ascii=False))
            time.sleep(10)  # 等待上传携程
            Hotel_id = Hotel_dict["masterHotelId"]
            room_list = Hotel_dict["roomList"]
            masterHotelName = Hotel_dict["masterHotelName"]
            try:
                HotelData_Dict = Ctrip_page_func.getroomlist(Hotel_id,Login_Option["duid"],Login_Option["ticket"],masterHotelName,proxy=ip)
                print(HotelData_Dict)
            except:
                Ctrip_sql_func.push_hotel_json_redis_contab(option.Redis_host_pub,option.Get_HotelPrice_ids_task,Hotel_dict)
                loguru.logger.error("IP失效，重新更换")
                continue
            if(HotelData_Dict == "ERROR"):
                #数据封禁账号状态
                Ctrip_sql_func.Update_account_state(option.DATA_SQL_CONF,Login_Option["id"],2)
                loguru.logger.error("账号已被封禁:"+json.dumps(Login_Option,ensure_ascii=False))
                log_fun.Logger_info(False,data="账号已被封禁:"+json.dumps(Login_Option,ensure_ascii=False))
                Ctrip_sql_func.push_hotel_json_redis_contab(option.Redis_host_pub,option.Get_HotelPrice_ids_task,Hotel_dict)
                continue
            if(HotelData_Dict == None):
                #账号登陆信息失效，重新获取登陆状态
                Login_Option = self.Formate_account(Login_Option,ip,option)
                HotelData_Dict = Ctrip_page_func.getroomlist(Hotel_id,Login_Option["duid"],Login_Option["ticket"],masterHotelName,proxy=ip)
                
            Ctrip_sql_func.Save_hotelPrice_lowest(HotelData_Dict=HotelData_Dict,Room_list=room_list)          
            cooling_time = option.COOL_TIME# 访问时间修改这里,方式携程大数据风控
            loguru.logger.info("等待时间："+str(cooling_time))
            time.sleep(cooling_time)
        
    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip = ipFun.Get_ip()
        ip = ip["Data"][0]["host"]
        loguru.logger.success("获取ip:"+ip)
        while (True):
            try:
                proxies = {
                "http": "http://"+ip,
                "https": "http://"+ip
                }
                requests.get("http://www.cip.cc",proxies=proxies)
                break
            except:
                loguru.logger.info("ip失效:"+ip)
                ip = self.Get_ip()
                continue
        return ip
    def Formate_account(self,Login_Option,ip,option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''        
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"],Login_Option["password"],ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF,Login_Option["username"],Login_Option["ticket"],Login_Option["duid"])
        return Login_Option

 
    


if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()



