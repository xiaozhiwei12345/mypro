'''
Author: wangjin
Date: 2022-02-28 15:46:38
LastEditTime: 2022-03-09 17:02:53
LastEditors: Please set LastEditors
Description: 数据库通用函数 *pymysql==0.9.3
FilePath: /ctrip_selenuim_test/cralwer_tools/Data_base_tools.py
'''

#coding: UTF-8
#pymysql==0.9.3



import pymysql



SQL_CONF = {
	"HOST":"49.232.4.181",
	"USERNAME":"Alipan_data",
	"PASSWD":"bhMNYRnS8wSxBTh3",
	"DATABASE":"alipan_data"
}





def insert_SQL(SQL_CONF,sql):
	HOST = SQL_CONF["HOST"]
	USERNAME = SQL_CONF["USERNAME"]
	PASSWD = SQL_CONF["PASSWD"]
	DATABASE = SQL_CONF["DATABASE"]
	db = pymysql.connect(host=HOST, user=USERNAME, password=PASSWD, database=DATABASE)
	cursor = db.cursor()
	cursor.execute(sql)
	db.commit()
	db.close()

def insert_SQL_GetData(SQL_CONF,sql):
	HOST = SQL_CONF["HOST"]
	USERNAME = SQL_CONF["USERNAME"]
	PASSWD = SQL_CONF["PASSWD"]
	DATABASE = SQL_CONF["DATABASE"]
	db = pymysql.connect(host=HOST, user=USERNAME, password=PASSWD, database=DATABASE)
	cursor = db.cursor()
	cursor.execute(sql)
	lis = cursor.fetchall()
	db.commit()
	db.close()
	return lis

#通用插入数据函数,生成sql语句
def insert_data_format_sql(tb_name, data_dict):
	sql = 'insert into ' + tb_name + '('
	# 获取字段列表
	for i in data_dict:
		sql += str(i) + ','
	sql = sql[:-1] + ') values ('
	# 加入每一条数据
	for i in data_dict:
		sql += '"' + str(data_dict[i]).replace('\t', '').replace('"', "'") + '",'
	sql = sql[:-1] + '),'
	# 去掉最后一个逗号
	sql = sql[:-1]
	return sql
def replace_data_format_sql(tb_name, data_dict):
	sql = 'replace into ' + tb_name + '('
	# 获取字段列表
	for i in data_dict:
		sql += str(i) + ','
	sql = sql[:-1] + ') values ('
	# 加入每一条数据
	for i in data_dict:
		sql += '"' + str(data_dict[i]).replace('\t', '').replace('"', "'") + '",'
	sql = sql[:-1] + '),'
	# 去掉最后一个逗号
	sql = sql[:-1]
	return sql
'''

SQL EXAMPLE

insert 
sql = ('insert into UniName_ID(UniName,UniID,Guid) values'
					# +'("' +  tmp[2] + '","' + str(i+1) +'","' +tmp[1] + '")')

update
sql = "update Account_pool set time_state="+timestamp+",use_count=use_count+1 where id="+str(id)+";"


'''

if __name__ == '__main__':
	print("123")
	dt = {
		"page_id":1,
		"title":"123"
	}
	print(insert_data_format_sql("tg_yunpanpan",dt))




