'''
Author: wangjin
Date: 2022-06-10 11:52:55
LastEditors: wangjin
LastEditTime: 2022-06-10 12:05:16
Description: 
'''

#定时任务
from apscheduler.schedulers.blocking import BlockingScheduler
def Monitor():
    scheduler = BlockingScheduler()
    scheduler.add_job (batch, "cron" , hour = 11, minute = 52 )
    scheduler.start()