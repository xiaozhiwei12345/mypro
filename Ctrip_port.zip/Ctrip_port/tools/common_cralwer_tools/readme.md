<!--
 * @Author: wangjin
 * @Date: 2022-03-16 11:31:55
 * @LastEditors: wangjin
 * @LastEditTime: 2022-03-16 11:36:09
 * @Description: 通用爬虫库 by wangjin
-->
# 通用爬虫库 by wangjin
# v0.1 日期：3.16
## 需求库
* pymysql==0.9.3
* 