'''
Author: your name
Date: 2022-03-02 11:26:51
LastEditTime: 2022-03-02 11:37:49
LastEditors: your name
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /ctrip_selenuim_test/Ip_proxy_tools/create_proxy_auth_extension.py
'''
import string
import zipfile


def create_proxyauth_extension(proxy_host, proxy_port, proxy_username, proxy_password, scheme='http', plugin_path=None):

    
    if(plugin_path is None):
        plugin_path = 'vim_chrome_proxyauth_plugin.zip'

    manifest_json = """ 
    { 
        "version": "1.0.0", 
        "manifest_version": 2, 
        "name": "Chrome Proxy", 
        "permissions": [ 
            "proxy", 
            "tabs", 
            "unlimitedStorage", 
            "storage", 
            "<all_urls>", 
            "webRequest", 
            "webRequestBlocking" 
        ], 
        "background": { 
            "scripts": ["background.js"] 
        }, 
        "minimum_chrome_version":"22.0.0" 
    } 
    """

    background_js = string.Template(
        """ 
        var config = { 
                mode: "fixed_servers", 
                rules: { 
                  singleProxy: { 
                    scheme: "${scheme}", 
                    host: "${host}", 
                    port: parseInt(${port}) 
                  }, 
                  bypassList: ["foobar.com"] 
                } 
              }; 

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {}); 

        function callbackFn(details) { 
            return { 
                authCredentials: { 
                    username: "${username}", 
                    password: "${password}" 
                } 
            }; 
        } 

        chrome.webRequest.onAuthRequired.addListener( 
                    callbackFn, 
                    {urls: ["<all_urls>"]}, 
                    ['blocking'] 
        ); 
        """
    ).substitute(
        host=proxy_host,
        port=proxy_port,
        username=proxy_username,
        password=proxy_password,
        scheme=scheme,
    )
    with zipfile.ZipFile(plugin_path, 'w') as zp:
        zp.writestr("manifest.json", manifest_json)
        zp.writestr("background.js", background_js)

    return plugin_path
