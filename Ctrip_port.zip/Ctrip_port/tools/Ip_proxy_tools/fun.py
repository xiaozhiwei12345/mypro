'''
Author: your name
Date: 2022-02-28 14:43:57
LastEditTime: 2022-06-07 17:13:40
LastEditors: wangjin
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /ctrip_selenuim_test/Ip_tools/Ip_fun.py
'''
import requests
import json
import urllib3
urllib3.disable_warnings()


class Ip_fun():
    BaseUrl = "https://proxy.qg.net/"
    Method = [
        "allocate",#提取IP
        "query",#查询IP
        "release"#释放
    ]

    def __init__(self):
        self.Key = 'C20A113E'

    def get_ip(self):
        Url = self.BaseUrl + "extract?"+"Key="+self.Key
        Jsons = requests.get(Url, verify=False).json()
        return Jsons

    def Query_using_ip(self,TaskID=None):
        Url = self.BaseUrl + "query?"+"Key="+self.Key+"&Detail=1"
        if(TaskID != None):
            Url += "&TaskID="+TaskID
        Jsons = requests.get(Url, verify=False).json()
        res_list = []
        for data in Jsons["TaskList"]:
            for Data in data["Data"]:
               res_list.append(Data) 
        return res_list
    def Release_ip(self,Ip_list,TaskID=None):
        Ip_para = ""
        for ip in Ip_para:
            ip += ip+","
        ip = ip[0:-1]
        Url = self.BaseUrl + "release?"+"Key="+self.Key+"&IP="+ip
        if(TaskID != None):
            Url += "&TaskID="+TaskID
        Jsons = requests.get(Url, verify=False).json()
        
        return Jsons

if __name__ == '__main__':
    fun = Ip_fun()
    print(fun.get_ip2())

        
        

        

        
        

    
    
    