# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:mysqlpipline.py
@Date:2022/7/30
"""

import pymysql

import time

ADB_HOST = '172.17.0.98'
ADB_PORT = 3306
ADB_USER = 'boss'
ADB_PWD = 'boss'
ADB_DB_NAME = 'boss'



class DaoMysql(object):
    def __init__(self):
        self.host = ADB_HOST
        self.username = ADB_USER
        self.database = ADB_DB_NAME
        self.port = ADB_PORT
        self.password = ADB_PWD
        self.db = pymysql.connect(host=self.host, user=self.username, password = self.password, database = self.database, port = self.port, charset='utf8mb4',cursorclass = pymysql.cursors.DictCursor)

    def _do_insert(self, table, item):
        self.cursor = self.db.cursor()
        cols = item.keys()
        pre_vals = ['%s'] * len(cols)
        act_vals = [item[col] for col in cols]
        sql = "INSERT INTO %s (%s) VALUES(%s)" % (table, ','.join(cols), ','.join(pre_vals))
        self.cursor.execute(sql, tuple(act_vals))
        self.db.commit()

    def _do_update(self, table, item, pri_key, pri_val):
        self.cursor = self.db.cursor()
        newItem = {}
        for colName in item.keys():
            colVal = item[colName]
            if hasattr(colVal, 'strip') and colVal.strip() == '':
                continue
            if colVal == 0 and colName not in ('iStatus',):
                continue
            newItem[colName] = colVal
        cols = newItem.keys()
        pre_vals = ["%s=%%s" % col for col in cols]
        act_vals = [newItem[col] for col in cols]
        sql = "UPDATE %s SET %s WHERE %s=%%s" % (table, ','.join(pre_vals), pri_key)
        act_vals.append(pri_val)
        self.cursor.execute(sql, tuple(act_vals))
        self.db.commit()

    def add_or_update(self, table, item, pri_key):
        self.cursor = self.db.cursor()
        sql = "SELECT * FROM `%s` WHERE `%s`='%s' LIMIT 1" % (table, pri_key, item[pri_key])
        print(sql)
        self.cursor.execute(sql)
        result = self.cursor.fetchone()

        if result:

                self._do_update(table, item, pri_key, item[pri_key])
                print("已经存在")


        else:

            self._do_insert(table, item)




    def delete_sql(self, sql):
        self.cursor = self.db.cursor()
        self.cursor.execute(sql)
        self.db.commit()

    def select_list(self, sql):
        self.cursor = self.db.cursor()
        self.cursor.execute(sql)
        return self.cursor.fetchall()




def publish_datetime():
    return int(time.time())



if __name__ == "__main__":
    daos = DaoMysql()
    sql = "show tables;"
    print(daos.select_list(sql))
