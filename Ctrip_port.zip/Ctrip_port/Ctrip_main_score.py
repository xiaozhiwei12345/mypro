# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:Ctrip_main_AIhotel.py
@Date:2022/7/18
"""
import re
from function import Ctrip_page_func
from function import Ctrip_sql_func
from Ctrip_port.tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options
import requests
import time
import loguru
import json
import pymysql
import mysqlpipline
conn = pymysql.connect(host='172.17.0.98', user='boss', password="boss", database='boss', port=3306)
# conn = pymysql.connect(host='172.17.0.191', user='spider_writer', password="@Uh5vIwhRd3!", database='boss', port=3306)
cursor = conn.cursor()


class Ctrip():

    mysql_obj = mysqlpipline.DaoMysql()
    def Batch(self):
        option = Ctrip_options.Options_class()

        # 获取携程酒店id任务列表
        res_data = requests.get("http://kong.whalepms.com:8000/admincenter/no-token/getHotelAiCtripIds").text
        res_data = json.loads(res_data)
        hotel_list = res_data['result']
        loguru.logger.success("成功获取任务: ")
        loguru.logger.success(hotel_list)

        # 获取ip
        ip = self.Get_ip()
        for hotel_id in hotel_list:
            loguru.logger.success("待爬取: " + str(hotel_id))

            try:
                res = requests.get(
                    url='https://hotels.ctrip.com/hotels/detail/?hotelId={}'.format(hotel_id),
                    headers={
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.47'
                    },
                    proxies=ip,
                   )

                init_data = re.search(pattern=r'window.IBU_HOTEL=({.*?});', string=res.text)

            except:
                # 任务请求失败，重新追加到任务列表
                hotel_list.append(hotel_id)
                loguru.logger.error("IP失效，重新更换")
                ip = self.Get_ip()
                continue

            if init_data:
                # 内置数据
                init_data = init_data.group(1)
                init_data = json.loads(init_data)
                # 酒店ID
                hotel_id = hotel_id
                # 酒店评分
                hotel_score = init_data['initData']['comment']['score']

                CrawlDate = time.strftime("%Y-%m-%d", time.localtime())
                CrawlTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

                item = {
                    'ctrip_id': hotel_id,
                    'date': CrawlDate,
                    'score': hotel_score,
                    'created_at': CrawlTime
                }

                self.mysql_obj.add_or_update()
                # sql_insert = 'insert into hotel_ai_ota_hotel_score_stat (ctrip_id, date, score, created_at) values ("{}","{}","{}","{}")'.format(
                #     hotel_id, CrawlDate, hotel_score, CrawlTime)
                # loguru.logger.success("执行sql: {}".format(sql_insert))
                # cursor.execute(sql_insert)
                # print("数据已添加")
                # conn.commit()

            else:
                hotel_list.append(hotel_id)
                continue

            cooling_time = 5  # 访问时间修改这里,方式携程大数据风控
            loguru.logger.info("等待时间：" + str(cooling_time))
            time.sleep(cooling_time)

    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip_json = ipFun.get_ip()
        ip = ip_json["Data"][0]["host"]
        loguru.logger.success("获取ip:" + ip)
        while True:
            try:
                key = 'C20A113E'
                passwd = '83425B8FC62D'
                proxy = 'http://{}:{}@{}'.format(key, passwd, ip)
                proxies = {
                    "http": proxy,
                    "https": proxy
                }
                requests.get("http://www.cip.cc", proxies=proxies, verify=False)
                break
            except:
                loguru.logger.info("ip失效:" + ip)
                ip_json = ipFun.get_ip()
                ip = ip_json["Data"][0]["host"]
                continue
        return proxies

    def Formate_account(self, Login_Option, ip, option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"], Login_Option["password"], ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF, Login_Option["username"], Login_Option["ticket"],
                                        Login_Option["duid"])
        return Login_Option


if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()
    cursor.close()
    conn.close()



