# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:Ctrip_main_random2.py
@Date:2022/8/12
"""
from function import Ctrip_page_func
from function import Ctrip_sql_func
from Ctrip_port.tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options
import requests
import time
import redis
import loguru
import json
from log_func import log_fun
from apscheduler.schedulers.blocking import BlockingScheduler

COOL_TIME = 10
REDIS_KEY = "Ctrip_hotel_tasks"


class Ctrip():

    def __init__(self):
        self.redis_cli = redis.StrictRedis(
            host="redis1.whalepms.com", port=6379, password="zUy0piREyUo", decode_responses=True)
        self.group_id = 101


    def Batch(self):

        option = Ctrip_options.Options_class()
        # 获取要爬得酒店任务
        while True:
            hotel_task = self.redis_cli.lpop(REDIS_KEY)
            loguru.logger.info("取到的任务为")
            loguru.logger.info(hotel_task)
            if hotel_task is not None:
                # 获取ip
                ip = self.Get_ip()
                hotel_dict = json.loads(hotel_task)
                # 获取账号
                login_account = Ctrip_sql_func.Get_usable_login_option(
                    option.DATA_SQL_CONF,
                    If_random=True,
                    group_id=self.group_id
                )
                if login_account is None:
                    break
                loguru.logger.success("待爬取:"+json.dumps(hotel_dict, ensure_ascii=False))
                # 任务酒店id
                Hotel_id = hotel_dict["masterHotelId"]
                # 任务酒店房型
                room_list = hotel_dict["roomList"]
                # 任务酒店名称
                masterHotelName = hotel_dict["masterHotelName"]
                try:
                    HotelData_Dict = Ctrip_page_func.getroomlist(
                        Hotel_id,
                        login_account["duid"],
                        login_account["ticket"],
                        masterHotelName,
                        proxy=ip
                    )
                except:
                    # 请求失败，任务重新加入队列
                    self.redis_cli.rpush(REDIS_KEY, json.dumps(hotel_dict, ensure_ascii=False))
                    loguru.logger.info("请求失败，任务重新加入队列")
                    loguru.logger.info(hotel_dict)
                    continue
                if HotelData_Dict == "ERROR":
                    # 数据封禁账号状态
                    Ctrip_sql_func.Update_account_state(option.DATA_SQL_CONF,login_account["id"],2)
                    loguru.logger.error("账号已被封禁:"+json.dumps(login_account,ensure_ascii=False))
                    log_fun.Logger_info(False,data="账号已被封禁:"+json.dumps(login_account,ensure_ascii=False))
                    # 账号被封任务重新加入队列
                    self.redis_cli.rpush(REDIS_KEY, json.dumps(hotel_dict, ensure_ascii=False))
                    loguru.logger.info("账号被封任务失败重新加入队列")
                    loguru.logger.info(hotel_dict)
                    time.sleep(10)
                    continue
                elif HotelData_Dict == "空字典":
                    continue
                elif HotelData_Dict == "重新登录":
                    # 账号登陆信息失效，重新获取登陆状态
                    Login_Option = self.Formate_account(login_account,ip,option)
                    HotelData_Dict = Ctrip_page_func.getroomlist(Hotel_id,Login_Option["duid"], Login_Option["ticket"], masterHotelName, proxy=ip)
                    if isinstance(HotelData_Dict, str):
                        loguru.logger.info("再次请求的结果************{}".format(HotelData_Dict))
                        self.redis_cli.rpush(REDIS_KEY, json.dumps(hotel_dict, ensure_ascii=False))
                        loguru.logger.info("参数更新后二次请求失败重新加入队列")
                        loguru.logger.info(hotel_dict)
                        time.sleep(10)
                        continue
                Ctrip_sql_func.Save_hotelPrice_lowest(HotelData_Dict=HotelData_Dict, Room_list=room_list)

                cooling_time = COOL_TIME  # 访问时间修改这里,方式携程大数据风控
                loguru.logger.info("等待时间："+str(cooling_time))
                time.sleep(cooling_time)
            else:
                loguru.logger.info("暂无任务等待30秒")
                time.sleep(30)

    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip = ipFun.get_ip()
        ip = ip["Data"][0]["host"]
        loguru.logger.success("获取ip:"+ip)
        while True:
            try:
                key = 'C20A113E'
                passwd = '83425B8FC62D'
                proxy = 'http://{}:{}@{}'.format(key, passwd, ip)
                proxies = {
                "http": proxy,
                "https": proxy
                }
                requests.get("http://www.cip.cc", proxies=proxies, verify=False)
                break
            except:
                loguru.logger.info("ip失效:"+ip)
                ip = ipFun.get_ip()
                ip = ip["Data"][0]["host"]
                continue
        return proxies
    def Formate_account(self,Login_Option,ip,option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"],Login_Option["password"],ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF,Login_Option["username"],Login_Option["ticket"],Login_Option["duid"])
        return Login_Option

    def Monitor(self):
        scheduler = BlockingScheduler()
        scheduler.add_job(self.Batch, "cron", hour=9, minute=10)
        scheduler.add_job(self.Batch, "cron", hour=10, minute=10)
        scheduler.add_job(self.Batch, "cron", hour=12, minute=10)
        scheduler.add_job(self.Batch, "cron", hour=14, minute=10)
        scheduler.add_job(self.Batch, "cron", hour=16, minute=10)
        scheduler.add_job(self.Batch, "cron", hour=18, minute=10)
        scheduler.add_job(self.Batch, "cron", hour=19, minute=30)
        scheduler.add_job(self.Batch, "cron", hour=21, minute=10)
        scheduler.start()


if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()
    # ctrip.Monitor()


