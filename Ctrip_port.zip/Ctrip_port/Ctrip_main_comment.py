# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:Ctrip_main_AIhotel.py
@Date:2022/7/18
"""

from function import Ctrip_page_func
from function import Ctrip_sql_func
from Ctrip_port.tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options
import requests
import time
import loguru
import json
from log_func import log_fun
import redis
import pymysql
# conn = pymysql.connect(host='172.17.0.98', user='boss', password="boss", database='boss', port=3306)
conn = pymysql.connect(host='172.17.0.191', user='spider_writer', password="@Uh5vIwhRd3!", database='boss', port=3306)
cursor = conn.cursor()

class Ctrip():
    # 分组使用账号
    group_id = 5

    def Batch(self):

        option = Ctrip_options.Options_class()

        # 获取携程酒店id任务列表
        res_data = requests.get("http://kong.whalepms.com:8000/admincenter/no-token/getHotelAiCtripIds").text
        res_data = json.loads(res_data)
        hotel_list = res_data['result']
        loguru.logger.success("成功获取任务: ")
        loguru.logger.success(hotel_list)
        # 获取ip
        ip = self.Get_ip()
        for hotel_id in hotel_list:

            # 获取账号
            Login_Option = Ctrip_sql_func.Get_usable_login_option(option.DATA_SQL_CONF, If_random=False,
                                                                  group_id=self.group_id)
            if Login_Option is None:  # 无可用账号时，跳出
                break

            loguru.logger.success("待爬取: " + str(hotel_id))

            try:
                data_tup = Ctrip_page_func.getCommentList(hotel_id, Login_Option["duid"], Login_Option["ticket"], proxy=ip)

            except:
                # 任务请求失败，重新追加到任务列表
                hotel_list.append(hotel_id)
                loguru.logger.error("IP失效，重新更换")
                # time.sleep(305)
                ip = self.Get_ip()
                continue
            if data_tup == "ERROR":
                # 账号被封
                Ctrip_sql_func.Update_account_state(option.DATA_SQL_CONF, Login_Option["id"], 2)
                loguru.logger.error("账号已被封禁:" + json.dumps(Login_Option, ensure_ascii=False))
                log_fun.Logger_info(False, data="账号已被封禁:" + json.dumps(Login_Option, ensure_ascii=False))
                hotel_list.append(hotel_id)
                continue
            # elif data_list == "空字典":
            #     continue
            # elif data_list == "重新登录":
            #     # 账号登陆信息失效，重新获取登陆状态
            #     Login_Option = self.Formate_account(Login_Option, ip, option)
            #     data_list = Ctrip_page_func.getsubRoomMap(hotel_id, Login_Option["duid"], Login_Option["ticket"], proxy=ip)

            othersCommentList, statisticInfo = data_tup
            score_info = {
                'ratingAll': statisticInfo['ratingAll'],
                'healthPoint': statisticInfo['healthPoint'],
                'environmentPoint': statisticInfo['environmentPoint'],
                'servicePoint': statisticInfo['servicePoint'],
                'facilityPoint': statisticInfo['facilityPoint']
            }
            print(score_info)
            comment_list = []
            for comment in othersCommentList:
                # 头像
                userPicture = comment.get('userPicture')
                # 昵称
                userNickName = comment.get('userNickName')
                # 等级
                commenterGrade = comment.get('commenterGrade')
                # 入住日期
                postDate = comment.get('postDate')
                # 分数
                ratingPoint = comment.get('ratingPoint')
                # 房型
                baseRoomName = comment.get('baseRoomName')
                # 标签
                travelType = comment.get('travelType')
                # 内容
                content = comment.get('content')
                # 图片
                imageList = comment.get('imageList')
                # 回复
                feedbackList = comment.get('feedbackList')
                if feedbackList:
                    feedback_content = feedbackList[0].get('content')
                else:
                    feedback_content = ''

                comment_dict = {
                    'userPicture' :userPicture,
                    'userNickName': userNickName,
                    'commenterGrade': commenterGrade,
                    'postDate': postDate,
                    'ratingPoint': ratingPoint,
                    'baseRoomName': baseRoomName,
                    'travelType': travelType,
                    'content': content,
                    'imageList': imageList,
                    'feedback_content': feedback_content

                }
                comment_list.append(comment_dict)
            CrawlTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            score_info = json.dumps(score_info, ensure_ascii=False)
            comment_list = json.dumps(comment_list, ensure_ascii=False)

            sql_insert = 'insert into hotel_ai_ota_hotel_comment_info (ctrip_id, scores_info, comment_info, created_at) values ("{}","{}","{}","{}")'.format(
                hotel_id, pymysql.escape_string(score_info), pymysql.escape_string(comment_list), CrawlTime)
            loguru.logger.success(f"执行sql: {sql_insert}")
            cursor.execute(sql_insert)
            # print("数据已添加")
            conn.commit()

            cooling_time = 10  # 访问时间修改这里,方式携程大数据风控
            loguru.logger.info("等待时间：" + str(cooling_time))
            time.sleep(cooling_time)



    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip_json = ipFun.get_ip()
        ip = ip_json["Data"][0]["host"]
        loguru.logger.success("获取ip:" + ip)
        while True:
            try:
                key = 'C20A113E'
                passwd = '83425B8FC62D'
                proxy = 'http://{}:{}@{}'.format(key, passwd, ip)
                proxies = {
                    "http": proxy,
                    "https": proxy
                }
                requests.get("http://www.cip.cc", proxies=proxies, verify=False)
                break
            except:
                loguru.logger.info("ip失效:" + ip)
                ip_json = ipFun.get_ip()
                ip = ip_json["Data"][0]["host"]
                continue
        return proxies

    def Formate_account(self, Login_Option, ip, option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"], Login_Option["password"], ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF, Login_Option["username"], Login_Option["ticket"],
                                        Login_Option["duid"])
        return Login_Option


if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()
    cursor.close()
    conn.close()



