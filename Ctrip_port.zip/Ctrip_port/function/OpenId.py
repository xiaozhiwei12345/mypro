# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:OpenId.py
@Date:2022/8/4
"""

open_id = [
    '6c2e6d49-386b-4f48-9892-d72c7975e8f9',
    '44c56703-16f5-44b2-a062-d17a346ecaf1',
    '3f5178d4-3330-4f8e-8b04-2c154ef68094',
    'eaecd744-8c7f-4ba9-9a25-0e018bb3ea1f',
    '65903c06-b71f-4104-8807-6bcdcc19553c',
    '794335f4-c9b8-499b-a0d7-27bbdb0259f7',
    '77eeb70f-8012-45d4-a580-6793ed4bf17f',
    '4a9aff58-9f07-47e9-b785-2908e4e5372c',
    '78699abe-dd1b-4d30-929f-253b048ba063',
    'b5bb5e4f-bf8d-4f37-83f0-184db7d3350f',
    'aece7e1a-d97a-462e-b8f4-05d781a4520f',
    '1eab0823-887e-44d1-9729-cc1decfe3ef5',
    'e48d49d4-0a5a-4890-9401-7ed9ea47a1c2',
    '820ef213-5c10-406e-bb4b-458bbe6ecdf5',
    'cf58a39e-e486-448d-9ab9-6467c1183180',
    '2d0c7886-93aa-45db-b5e4-3f260496bf6e',
    '0d32e102-158d-44f4-8f14-9eaafe09f8ec',
    '0461fc30-4ec6-4c29-89d6-dcefc785f31a',
    'bc9b389d-1b82-4c5d-832e-7fca8a13647d',
]