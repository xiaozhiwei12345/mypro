'''
Author: wangjin
Date: 2022-03-09 10:15:00
LastEditors: wangjin
LastEditTime: 2022-07-01 10:23:54
Description: 
'''
import time

'''
Author: your name
Date: 2022-02-28 15:55:41
LastEditTime: 2022-05-25 20:29:28
LastEditors: wangjin
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /ctrip_selenuim_test/Ctrip_tools_sql.py
'''
from redis import Redis

from Ctrip_port.tools.common_cralwer_tools import Database_tools as DB_tools
import loguru
import json
import redis
import requests
from Ctrip_port.log_func import log_fun
from Ctrip_port import Ctrip_options
option = Ctrip_options.Options_class() 

DEMO_SQL_CONF = {
    "HOST": "172.17.1.133",
            "USERNAME": "Ota_hotel",
            "PASSWD": "A7MkZWcCHm4Ak7rN",
            "DATABASE": "ota_hotel"
}
DEMO_Redis_host = "172.17.1.133"


# 提交爬虫数据
def Save_hotelPrice_lowest(HotelData_Dict, Room_list):
    postUrl = "http://ota.inner.whalepms.com:83/ota/updateGrabInfo"
    unshow_roomid = Room_list
    masterHotelId = HotelData_Dict["hotelId"]
    HotelData_Dict["unshow"] = []
    price_post_dict = {
        "masterHotelId": masterHotelId,
        "roomInfos": [
            # {
            #     "masterRoomId": "31415926",
            #     "lowestPrice": 99,
            #     "roomStatue": 0,
            #     "roomId": "-1"
            # }
        ],
        "showInfos":[

        ]
    }

    for roomsData in HotelData_Dict["roomsData"]:
        baseRoomId = roomsData["baseRoomId"]  # 母房型id

        # 此处是判断价格
        FirstCardsData = roomsData["saleCards"][0]
        ubt_roomids = int(FirstCardsData["ubt_roomid"])
        # 组合返回房间数据
        if int(ubt_roomids) in Room_list:  # 判断第一个是否是我们的房间
           #  将外网最低价第二个房价数据返回
           if len(roomsData["saleCards"]) > 1:
                second_cards_data = roomsData["saleCards"][1]
                price_post_dict["roomInfos"].append({
                        "masterRoomId": baseRoomId,
                        "lowestPrice": second_cards_data["price"],
                        "roomStatue": second_cards_data["roomStatue"],
                        "breakfastNum": second_cards_data["breakfast"]
                    })

        else:
            price_post_dict["roomInfos"].append({
                            "masterRoomId": baseRoomId,
                            "lowestPrice": FirstCardsData["price"],
                            "roomStatue": FirstCardsData["roomStatue"],
                            "breakfastNum": FirstCardsData["breakfast"]
                        })
        # 此处仅判断是否露出，因为露出的子房间可能在后面所以单独判断
        for num in range(len(roomsData["saleCards"])):
            cardsData = roomsData["saleCards"][num]
            ubt_roomid = int(cardsData["ubt_roomid"])
            price = cardsData["price"]
            if int(ubt_roomid) in unshow_roomid:  # 如果露出了上传露出接口
                unshow_roomid.remove(ubt_roomid)  # 最后未露出的一起放在接口，标记为未露出
                price_post_dict["showInfos"].append({
                    "roomId": ubt_roomid,
                    "ifShow": 2,
                    "showPrice": price
                })

                # 存到log中得数据
                roomsData["saleCards"][num]["If_show"] = num+1
                roomsData["saleCards"][num]["Gap_price"] = price-roomsData["saleCards"][0]["price"]

    for id in unshow_roomid:
        price_post_dict["showInfos"].append({
                    "roomId": id,
                    "ifShow": 1,
                })
        HotelData_Dict["unshow"].append({"ubt_roomid":id,"If_show":0})

    # 返回后台数据
    price_post_data = json.dumps(price_post_dict, ensure_ascii=False)
    price_post_data = price_post_data.replace("'", '"')
    requests.post(postUrl, data=price_post_data, headers={"Content-Type":"application/json"})
    loguru.logger.success("传送价格json\n"+price_post_data)

    #保存日志
    log_fun.Logger_info(True, json.dumps(HotelData_Dict, ensure_ascii=False))
    log_fun.Logger_price(HotelData_Dict)
    # 保存最低价
    log_fun.Logger_lowest_price(price_post_dict)


def Save_ticket_duid(SQL_CONF,username,ticket,duid):
    '''
    description: 在数据库保存 接口用参数
    return {*}
    '''    
    SQL = "UPDATE Account_ctrip SET duid='"+duid+"',ticket='"+ticket+"' WHERE username='"+username+"';"
    print(SQL)
    DB_tools.insert_SQL(SQL_CONF=SQL_CONF, sql=SQL)
    loguru.logger.success("更新tictet:"+ticket+"duid:"+ticket)


def Get_usable_login_option(SQL_CONF,If_random=False,group_id = 1):
    '''
    description: 获取一个随机账号
    return {*}
    '''
    # if If_random:
    #     # SQL = "SELECT * FROM Account_ctrip WHERE state=0 AND use_group="+str(group_id)+" ORDER BY RAND() LIMIT 1;"
    #     SQL = "SELECT * FROM Account_ctrip WHERE state=0 ORDER BY RAND() LIMIT 1;"
    # else:
    # 分组取账号
    SQL = "SELECT * FROM Account_ctrip WHERE state=0 AND use_group="+str(group_id)+" ORDER BY RAND() LIMIT 1;"
    sql_res = DB_tools.insert_SQL_GetData(SQL_CONF=SQL_CONF, sql=SQL)
    if len(sql_res) == 0:
        loguru.logger.error("无可用账号，请去数据库Ctrip_account表查看。")

    else:
        sql_res = sql_res[0]
        SQL = "UPDATE Account_ctrip SET use_times=use_times+1,userTask='"+option.TaskName+"' WHERE id="+str(sql_res[0])
        DB_tools.insert_SQL(SQL_CONF=SQL_CONF, sql=SQL)
        Login_Option = {
        "id":str(sql_res[0]),
        "username": sql_res[3],
        "password": sql_res[2],
        "phone":sql_res[1],
        "duid":sql_res[6],
        "ticket":sql_res[7],

    }
        loguru.logger.success("登陆组获取成功： "+ json.dumps(Login_Option,ensure_ascii=False))
        return Login_Option


def Update_account_state(SQL_CONF,id,state):
    '''
    description: ban掉一个账号
    return {*}
    '''    
    SQL = "UPDATE Account_ctrip SET state="+str(state)+" WHERE id="+str(id)
    DB_tools.insert_SQL(SQL_CONF=SQL_CONF, sql=SQL)


def Get_hotel_json_redis(Redis_host, Redis_list_name):
    '''
    获取任务从redis,弹出一个，在尾部添加，做一个轮询任务
    '''
    Redis = redis.StrictRedis(
        host=Redis_host, port=6379, decode_responses=True)
    res_json = Redis.lpop(Redis_list_name)
    Redis.rpush(Redis_list_name, res_json)
    res_json = res_json.replace("'", '"')

    return json.loads(res_json)
# 组合任务
def com_task(task_list):
    hotel_ids = [i['masterHotelId'] for i in task_list]
    # 去重保持顺序酒店id
    hotel_ids = list(set(hotel_ids))

    com_task_list = []
    for hotel_id in hotel_ids:
        com_dict = {'roomList': []}
        for i_dict in task_list:
            masterHotelId = i_dict['masterHotelId']
            if masterHotelId == hotel_id:
                com_dict['masterHotelId'] = hotel_id
                com_dict["masterHotelName"] = i_dict['masterHotelName']
                com_dict["otaChannelId"] = "ctrip"
                com_dict['roomList'] = com_dict['roomList'] + i_dict['roomList']
        com_dict['roomList'] = list(set(com_dict['roomList']))
        com_task_list.append(com_dict)

    return com_task_list

def removeduplicate(list1):
    """
    列表套字典去重复
    :param list1: 输入一个有重复值的列表
    :return: 返回一个去掉重复的列表
    """
    newlist = []
    for i in list1:  # 先遍历原始字典
        flag = True
        if newlist == []:  # 如果是空的列表就不会有重复，直接往里添加
            pass
        else:
            for j in newlist:
                count = len(i.keys())
                su = 0
                for key in i.keys():
                    if i[key] == j[key]:
                        su += 1
                if su == count:
                    flag = False
        if flag:
            newlist.append(i)
    return newlist


def Get_hotel_json_redis_contab(Redis_list_name):
    '''
    获取任务从redis,弹出一个,不回推一个
    '''
    Redis = redis.StrictRedis(
        host="redis1.whalepms.com", port=6379, password="zUy0piREyUo", decode_responses=True)
    # res_json = Redis.lrange(Redis_list_name, 0, -1)
    res_dict_list = []
    res = Redis.lpop(Redis_list_name)
    while res is not None:
        res_json = res.replace("'", '"')
        res_dict = json.loads(res_json)
        res_dict_list.append(res_dict)
        res = Redis.lpop(Redis_list_name)
    # 去重任务列表
    # print(res_json_list)
    task_list = com_task(res_dict_list)
    task_list = removeduplicate(task_list)

    return task_list


def push_hotel_json_redis_contab(Redis_list_name,Hotel2room_dict):
    '''
    推到结尾一个数据，用于当前任务失败，吧任务推到队尾
    '''
    Redis_cli = redis.StrictRedis(
        host="redis1.whalepms.com", port=6379, password="zUy0piREyUo", decode_responses=True)
    Redis_cli.rpush(Redis_list_name, json.dumps(Hotel2room_dict,ensure_ascii=False))

def Get_Hotel2room_dict_redis(Redis_host, Redis_list_name):
    '''
    获取任务从redis,弹出一个，在尾部添加，做一个轮询任务
    '''
    Redis = redis.StrictRedis(
        host=Redis_host, port=6379, decode_responses=True)
    Hotel2room_dict = Redis.lpop(Redis_list_name)
    Redis.rpush(Redis_list_name, Hotel2room_dict)
    loguru.logger.success("正在检查价格是否露出的酒店列表为："+str(Hotel2room_dict))
    Hotel2room_dict = json.loads(Hotel2room_dict)
    return Hotel2room_dict


if __name__ == '__main__':
    # print(Get_hotel_id_redis())
    # Redis = redis.StrictRedis(host=Redis_host,port=6379,decode_responses=True)
    # Redis.rpush("Ctrip_lowest_pub","123"+":"+"456")
    # Data = {"hotelId": "23784965", "cralwerTime": "2022-06-14 11:05:30", "roomsData": [{"baseRoomId": 94141751, "roomName": "舒适大床间", "saleCards": [{"ubt_roomid": 221385511, "price": 129, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 94141752, "roomName": "舒适标准间", "saleCards": [{"ubt_roomid": 221385512, "price": 129, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 94141749, "roomName": "豪华标准间", "saleCards": [{"ubt_roomid": 221385509, "price": 138, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 94141750, "roomName": "豪华大床间", "saleCards": [{"ubt_roomid": 221385510, "price": 138, "breakfast": 0, "roomStatue": 0}]}, {"baseRoomId": 94141753, "roomName": "舒适三人间", "saleCards": [{"ubt_roomid": 221385513, "price": 155, "breakfast": 0, "roomStatue": 0}]}], "masterHotelName": "泗洪天和精品酒店"}
    #
    # room_list = [221385511]
    while True:
        print(Get_hotel_json_redis_contab(Redis_list_name="Ctrip_task"))
        time.sleep(60)

