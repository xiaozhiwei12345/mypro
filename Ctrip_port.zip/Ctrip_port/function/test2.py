# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:test2.py
@Date:2022/7/25
"""
import json
import os
import requests
import psutil
import time
# from fake_useragent import UserAgent

# print(UserAgent().random)
# import pymysql
# conn = pymysql.connect(host='172.17.0.191', user='spider_writer', password="@Uh5vIwhRd3!", database='boss', port=3306)
# cursor = conn.cursor()
# sql = 'select * from Account_ctrip where use_group=1 and state=2'
# cursor.execute(sql)
# print(cursor.fetchall())
# exit()
# while True:
#
#     if 1860 in pids:
#         print('程序正常运行')
#     else:
#         url = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=caf16f8d-c13e-4f68-9979-ebf1090dc23f"
#
#         payload = {
#             "msgtype": "text",
#             "text": {
#                 "content": "宝贝,你的爬虫程序-房态挂了, 来看看我"
#             }
#         }
#         headers = {
#             'Content-Type': 'application/json'
#         }
#
#         response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
#
#         print(response.text)
#         break
#     time.sleep(5)
import redis

Redis = redis.StrictRedis(
        host="redis1.whalepms.com", port=6379, password="zUy0piREyUo", decode_responses=True)


d = ['{"masterHotelId":6955579,"masterHotelName":"长沙四叶草商院宾馆","otaChannelId":"ctrip","roomList":[1264122892,1264122894,1264122896,1264122898,1264122900,1264122901,1264122903],"testOrderFlag":false}', '{"masterHotelId":3796781,"masterHotelName":"长沙武广酒店公寓","otaChannelId":"ctrip","roomList":[1263219339,1263219344,1263219346,1263219349,1263219354,1263219359,1263219365],"testOrderFlag":false}', '{"masterHotelId":4016798,"masterHotelName":"爱丽舍精品酒店(长沙绿地中央广场观沙岭地铁站店)","otaChannelId":"ctrip","roomList":[1264121596,1264121597,1264121600,1264121602,1264121603],"testOrderFlag":false}']

for i in d:
    Redis.lpush('Ctrip_task', i)
# while True:
#     res_json = Redis.lpop('Ctrip_task')
#     if res_json:
#         print(res_json)
#     else:
#         print(res_json)
#     time.sleep(5)
