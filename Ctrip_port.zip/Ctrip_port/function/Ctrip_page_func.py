from datetime import date, timedelta
from Ctrip_port.log_func import log_fun
import requests
import json
import loguru
# from fake_useragent import UserAgent
from Ctrip_port.function import ua
from Ctrip_port.function import OpenId
import random
import time


def userValidateNoRisk(userName, passwd, proxy):
    '''
    description: 获取userLogin的certificateCode
    return certificateCode
    '''
    proxies = proxy
    url = "https://passport.ctrip.com/gateway/api/soa2/12559/userValidateNoRisk"
    postData = {
    "AccountHead": {
        "Platform": "P",
        "Extension": {}
    },
    "Data": {
        "accessCode": "7434E3DDCFF0EDA8",
        "strategyCode": "698D04A841768C87",
        "userName": userName,
        "certificateCode": passwd,
        "extendedProperties": [
            {
                "key": "LoginName",
                "value": userName
            },
            {
                "key": "Platform",
                "value": "P"
            },
            {
                "key": "PageId"
            },
            {
                "key": "URL",
                "value": "https://passport.ctrip.com/user/login?BackUrl=https%3A%2F%2Fwww.ctrip.com%2F#ctm_ref=c_ph_login_buttom"
            },
            {
                "key": "http_referer",
                "value": "https://www.ctrip.com/"
            },
            {
                "key": "rmsToken",
                "value": "fp=1uiqjtv-b7ni15-141b8ie&vid=1654568331236.46xj5v&pageId=&r=d78ac434e2a647289547f852f580d97d&ip=223.104.213.58&rg=fin&kpData=0_0_0&kpControl=0_0_0-0_0_0&kpEmp=0_0_0_0_0_0_0_0_0_0-0_0_0_0_0_0_0_0_0_0-0_0_0_0_0_0_0_0_0_0&screen=1920x1080&tz=+8&blang=zh-CN&oslang=zh-CN&ua=Mozilla%2F5.0%20(Macintosh%3B%20Intel%20Mac%20OS%20X%2010_15_7)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F102.0.0.0%20Safari%2F537.36&d=passport.ctrip.com&v=25&kpg=0_1_0_0_202_2_0_0_0_0&adblock=F&cck=F"
            }
        ]
    }
    }
    postRes = requests.post(url=url, data=json.dumps(postData),headers={"Content-Type":"application/json",'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Redmi Note 4 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.99 XWEB/3209 MMWEBSDK/20220204 Mobile Safari/537.36 MMWEBID/2173 MicroMessenger/8.0.20.2100(0x28001439) Process/appbrand1 WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64 MiniProgramEnv/android'},proxies=proxies).json()
    print(json.dumps(postRes, ensure_ascii=False))
    if(postRes['Message'] == '成功'):
        Result = postRes['Result']
        resdict = json.loads(Result)
        token = resdict["token"]
        return token
    else:
        loguru.logger.error(json.dumps(postRes, ensure_ascii=False))
        return None


def userLogin(certificateCode,proxy):
    url = "https://passport.ctrip.com/gateway/api/soa2/12559/userLogin"
    # proxies = {
    # "http": "http://"+proxy,
    # "https": "http://"+proxy
    # }
    proxies = proxy
    postData = {
    "Data": {
        "accessCode": "7434E3DDCFF0EDA8",
        "strategyCode": "A3D2BC8A25ECAC77",
        "loginName": "",
        "certificateCode": certificateCode,
        "extendedProperties": [
            {
                "key": "Platform",
                "value": "P"
            },
            {
                "key": "PageId"
            },
            {
                "key": "URL",
                "value": "https://passport.ctrip.com/user/login?BackUrl=https%3A%2F%2Fwww.ctrip.com%2F#ctm_ref=c_ph_login_buttom"
            },
            {
                "key": "http_referer",
                "value": "https://www.ctrip.com/"
            },
            {
                "key": "rmsToken",
                "value": ""
            }
        ]
    }
}
    postRes = requests.post(url=url, data=json.dumps(postData),headers={"Content-Type":"application/json",'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Redmi Note 4 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.99 XWEB/3209 MMWEBSDK/20220204 Mobile Safari/537.36 MMWEBID/2173 MicroMessenger/8.0.20.2100(0x28001439) Process/appbrand1 WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64 MiniProgramEnv/android'},proxies=proxies).json()
    if(postRes['Message'] == '成功'):
        Result = postRes['Result']
        resdict = json.loads(Result)
        ticket = resdict["ticket"]
        duid = resdict["duid"]
        return (ticket,duid)
    else:
        return None


def getroomlist(hotelId, duid, ticket, masterHotelName, proxy):

    user_agent = random.choice(ua.user_agent)
    # print(user_agent)
    open_id = random.choice(OpenId.open_id)
    print(open_id)

    proxies = proxy
    headers = {
        'Host': 'm.ctrip.com',
        'Connection': 'keep-alive',
        'x-ctx-currency': 'CNY',
        # 'cookie': 'Union=OUID=&AllianceID=262684&SID=711465&SourceID=55552689;DUID='+duid+';GUID=52271046211023456437;',

        'cookie': 'Union=OUID=mini1005&AllianceID=263528&SID=1105084&SourceID=55555546;DUID='+duid+';GUID=52271030210972537185',
        'x-ctx-region': 'CN',
        'content-type': 'application/json',
        'User-Agent': user_agent,
        # 'User-Agent': UserAgent().random,
        'duid': duid,
        'Accept-Encoding': 'gzip,compress,br,deflate',
        'x-ctx-locale': 'zh-CN',
        'x-wx-openid': open_id,
        # 'x-wx-openid': '44c56703-16f5-44b2-a062-d17a346ecaf1',
        'charset': 'utf-8',
        'x-ctx-group': 'ctrip',
        'x-ctx-personal-recommend': '1',
        'Referer': 'https://servicewechat.com/wx0e6ed4f51db9d078/617/page-frame.htm'

    }
    # 今天
    today = date.today()

    # 明天
    tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
    post_data = {
    "hotelId":hotelId,
    "checkinDate":str(today),
    "checkoutDate":str(tomorrow),
    "payType": 0,
    "filterItemList": [],
    "isHourRoomSearch":False,
    "passFromList": "vG9Trw5XegBTsUNI+b+aA+QDulS6epUrwzDLZJY9h7D2bszdXUu/PzqoI/t3H7UBHvAX2tk4nbES4iCiJG8DyE+Eo/iv0fLneqlFXV9ftn1Jb4HwomOy0knTJlwTmG/zmKLvJtGM1AS5zPHeZE3ekW+WTPdqXPBrEIXg0SRMce3zHLxMMT8LLsV75jrTJTno",
    "session": {
        "key": "f5cebede8b990b99cdd417db9b98eebe45d715d3dcab9897bf5c8883525cbd2e",
        "sessionKey": "173a28f8-48dc-40e0-b733-55432d675b00"
    },
    "head": {
        "cid": "52271046211023456437",
        "ctok": "",
        "cver": "1.1.137",
        "lang": "01",
        "sid": "",
        "syscode": "30",
        "auth":ticket,
        "sauth": "",
        "extension": [
            {
                "name": "sdkversion",
                "value": "2.23.4"
            },
            {
                "name": "openid",
                "value": open_id
            },
            {
                "name": "pageid",
                "value": "10650028227"
            },
            {
                "name": "supportWebP",
                "value": "true"
            },
            {
                "name": "appId",
                "value": "wx0e6ed4f51db9d078"
            },
            {
                "name": "scene",
                "value": "1027"
            }
        ]
    }
}
    
    resJson = requests.post(url="https://m.ctrip.com/restapi/soa2/22370/getroomlist?_fxpcqlniredt=52271046211023456437",data=json.dumps(post_data,ensure_ascii=False),headers=headers,proxies=proxies).text
    with open("log/resJson.csv", "a", encoding="utf-8") as f:
        f.write(str(hotelId)+"\t"+masterHotelName+"\t"+str(today)+"\t"+resJson+"\t"+"\n")
    if "白银贵宾" in resJson:
        with open("log/guibin.csv","a",encoding="utf-8") as f:
            f.write(str(hotelId)+","+masterHotelName+",1,"+str(today)+"\n")
    else:
        with open("log/guibin.csv","a",encoding="utf-8") as f:
            f.write(str(hotelId)+","+masterHotelName+",0,"+str(today)+"\n")
    # print(resJson)
    resJson = json.loads(resJson)
    subRoomMap = resJson.get("subRoomMap")
    # 返回状态码
    result = resJson.get('result')

    # 解析,格式化要返回得数据
    # 1.正常返回， 2.酒店售完没有任何房型，返回空字典{} 3，账号被封返回状态码203   4.登录过期返回状态码201
    if result == 0 and subRoomMap:
        formateDict = formate_subRoomMap(subRoomMap, hotelId)
        formateDict["masterHotelName"] = masterHotelName
        return formateDict
    elif result == 0 and subRoomMap == {}:
        return '空字典'
    elif result == 203 and subRoomMap is None:
        return "ERROR"  # 号被封了
    elif result == 201 and subRoomMap is None:
        return "重新登录"


# 解析数据格式化
def formate_subRoomMap(subRoomMap,hotelId):
    HotelData_Dict = {
        "hotelId": str(hotelId),
        "cralwerTime": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
        "roomsData": []
    }

    # roomCardsList = []
    baseRoomId_t = ""
    for room_data in subRoomMap.values():
        # 售卖房id
        ubt_roomid = room_data.get('id')
        # 房型id
        baseRoomId = room_data.get('baseRoomId')
        # 房型名称
        roomName = room_data.get('name')
        # 有无早餐
        breakfast = room_data.get('breakfast')
        # 是否是钟点房
        isHourRoom = room_data.get('isHourRoom')
        if isHourRoom == 1:
            continue
        if breakfast == "无早餐":
            breakfast = 0
        elif breakfast == "1份早餐":
            breakfast = 1
        elif breakfast == "2份早餐":
            breakfast = 2
        elif breakfast == "3份早餐":
            breakfast = 3
        # 房间在售状态，在售，满房，关闭
        status = room_data.get('status')
        if status == 1:
            roomStatue = 0
        elif status == 3:
            roomStatue = 1
        elif status == 2:
            roomStatue = 2
        # 房间价格
        price = room_data.get('price')

        # 组合所有售卖房型数据
        if baseRoomId != baseRoomId_t:
            baseRoomId_t = baseRoomId
            roomsDataDict = {
                "baseRoomId": baseRoomId,
                "roomName": roomName,
                "saleCards": [
                {
                    "ubt_roomid": ubt_roomid,
                    "price": price,
                    "breakfast": breakfast,
                    "roomStatue": roomStatue
                }
            ]
            }
            HotelData_Dict["roomsData"].append(roomsDataDict)
        else:
            saleCards = {
                    "ubt_roomid":ubt_roomid,
                    "price":price,
                    "breakfast":breakfast,
                    "roomStatue":roomStatue
                }
            HotelData_Dict["roomsData"][-1]["saleCards"].append(saleCards)
    return HotelData_Dict
    
    
def Get_ticket_duid(username,password,ip):
    #爬虫第一步获取certificateCode
    certificateCode = userValidateNoRisk(username,password,proxy=ip)
    loguru.logger.success("certificateCode:"+str(certificateCode))
    #爬虫第二步获取ticket与DUID
    login_parm = userLogin(certificateCode,proxy=ip)
    
    ticket = login_parm[0]
    duid = login_parm[1]
    loguru.logger.success("账号失效 重新拉取登陆参数，ticket:"+ticket+" duid:"+duid)
    return ticket, duid


def getsubRoomMap(hotelId, duid, ticket, proxy):
    # proxies = {
    #     "http": "http://"+proxy,
    #     "https": "http://"+proxy
    #     }
    proxies = proxy
    headers = {
        'Host': 'm.ctrip.com',
        'Connection': 'keep-alive',
        'x-ctx-currency': 'CNY',
        # 'cookie': 'Union=OUID=&AllianceID=262684&SID=711465&SourceID=55552689;DUID=u=0E12092ECD4771E1490C820890BC7BF4&v=0;GUID=52271046211023456437;',

        'cookie': 'Union=OUID=mini1005&AllianceID=263528&SID=1105084&SourceID=55555546;DUID=' + duid + ';GUID=52271030210972537185',
        'x-ctx-region': 'CN',
        'content-type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Redmi Note 4 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.99 XWEB/3209 MMWEBSDK/20220204 Mobile Safari/537.36 MMWEBID/2173 MicroMessenger/8.0.20.2100(0x28001439) Process/appbrand1 WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64 MiniProgramEnv/android',
        'duid': duid,
        'Accept-Encoding': 'gzip,compress,br,deflate',
        'x-ctx-locale': 'zh-CN',
        'x-wx-openid': '44c56703-16f5-44b2-a062-d17a346ecaf1',
        'charset': 'utf-8',
        'x-ctx-group': 'ctrip',
        'x-ctx-personal-recommend': '1',
        'Referer': 'https://servicewechat.com/wx0e6ed4f51db9d078/561/page-frame.htm'

    }
    # 今天
    today = date.today()

    # 明天
    tomorrow = (date.today() + timedelta(days=1)).strftime("%Y-%m-%d")
    p_data = {"hotelId":hotelId,"checkinDate":str(today),"checkoutDate":str(tomorrow),"payType":0,"filterItemList":[],"isHourRoomSearch":False,"passFromList":"vG9Trw5XegBTsUNI+b+aA+eKKVQ1TAYwZxPd2X72Am9WXEjyIgSSILljhqTeIanIjh6fqbYmgu02Pmtzp1+dlk+Eo/iv0fLneqlFXV9ftn16frxzEMiX7k/LhFLbjncLvSFGSPdhQraqsw5UnE2yOY9OoKtr41U7sUD8SJJWL6LhIQ7z31mizEH099Q2VaeZ","session":{"key":"ef41264a157b348bac6ddb01c326b81c963b5974d6599731f9e1d2289c1abcf4","sessionKey":"e33af0f1-b145-4f0e-9d3e-619a5089804b"},"head":{"cid":"52271030210972537185","ctok":"","cver":"1.1.120","lang":"01","sid":"","syscode":"30","auth":f"{auth}","sauth":"","extension":[{"name":"sdkversion","value":"2.23.2"},{"name":"openid","value":"44c56703-16f5-44b2-a062-d17a346ecaf1"},{"name":"pageid","value":"10650028227"},{"name":"supportWebP","value":"true"},{"name":"ubt","value":"{\"vid\":\"1648713663812.ph0d6u\",\"sid\":3,\"pvid\":27,\"ts\":1648779964542,\"create\":1648713663812,\"pid\":\"10650012159\"}"},{"name":"appId","value":"wx0e6ed4f51db9d078"},{"name":"scene","value":"1027"}]}}
    '''
    post_data = {
        "hotelId": hotelId,
        "checkinDate": str(today),
        "checkoutDate": str(tomorrow),
        "payType": 0,
        "filterItemList": [],
        "isHourRoomSearch": False,
        "passFromList": "vG9Trw5XegBTsUNI+b+aA+eKKVQ1TAYwZxPd2X72Am9WXEjyIgSSILljhqTeIanIjh6fqbYmgu02Pmtzp1+dlk+Eo/iv0fLneqlFXV9ftn16frxzEMiX7k/LhFLbjncLvSFGSPdhQraqsw5UnE2yOY9OoKtr41U7sUD8SJJWL6LhIQ7z31mizEH099Q2VaeZ",
        "session": {
            "key": "ef41264a157b348bac6ddb01c326b81c963b5974d6599731f9e1d2289c1abcf4",
            "sessionKey": "e33af0f1-b145-4f0e-9d3e-619a5089804b"
        },
        "head": {
            "cid": "52271030210972537185",
            "ctok": "",
            "cver": "1.1.120",
            "lang": "01",
            "sid": "",
            "syscode": "30",
            "auth": ticket,
            "sauth": "",
            "extension": [
                {
                    "name": "sdkversion",
                    "value": "2.23.2"
                },
                {
                    "name": "openid",
                    "value": "44c56703-16f5-44b2-a062-d17a346ecaf1"
                },
                {
                    "name": "pageid",
                    "value": "10650028227"
                },
                {
                    "name": "supportWebP",
                    "value": "true"
                },
                {
                    "name": "appId",
                    "value": "wx0e6ed4f51db9d078"
                },
                {
                    "name": "scene",
                    "value": "1027"
                }
            ]
        }
    }
    '''
    url = 'https://m.ctrip.com/restapi/soa2/22370/getroomlist?_fxpcqlniredt=52271030210972537185'
    res_json = requests.post(url=url,
                            data=json.dumps(p_data, ensure_ascii=False), headers=headers, proxies=proxies).text
    res_json = json.loads(res_json)
    subRoomMap = res_json.get("subRoomMap")
    # 返回状态码
    result = res_json.get('result')

    # 解析,格式化要返回得数据
    # 1.正常返回， 2.酒店售完没有任何房型，返回空字典{} 3，账号被封返回状态码203   4.登录过期返回状态码201
    if result == 0 and subRoomMap:
        house_type_dict = parse_data(res_json)
        data_list = parse_price(subRoomMap, hotelId, house_type_dict)
        return data_list
    elif result == 0 and subRoomMap == {}:
        return '空字典'
    elif result == 203 and subRoomMap is None:
        return "ERROR"  # 号被封了
    elif result == 201 and subRoomMap is None:
        return "重新登录"


# 处理价格数据
def parse_price(subRoomMap, hotelid, house_type_dict):
    data_list = []
    house_type_keys = list(house_type_dict.keys())
    for room_data in subRoomMap.values():
        # 是否是钟点房
        isHourRoom = room_data.get('isHourRoom')
        # 售卖房id
        ubt_roomid = room_data.get('id')
        # 房型id
        baseRoomId = room_data.get('baseRoomId')
        # 房型名称
        roomName = room_data.get('name')
        # 房间价格
        price = room_data.get('price')
        filterIds = room_data.get('filterIds')
        filter_id_list = [i for i in filterIds if i in house_type_keys]
        if filter_id_list:
            filter_id = filter_id_list[0]
            filter_id = filter_id[-1]
        else:
            filter_id = None
        CrawlTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        data_time = time.strftime("%Y-%m-%d %H", time.localtime())

        data_dict = {
            'hotelid': hotelid,
            'baseRoomId': baseRoomId,
            'ubt_roomid': ubt_roomid,
            'roomName': roomName,
            'isHourRoom': isHourRoom,
            'price': price,
            'filter_id': filter_id,
            'CrawlTime': CrawlTime,
            'data_time': data_time
        }
        data_list.append(data_dict)
        print(hotelid, baseRoomId, ubt_roomid, roomName, price, filter_id, CrawlTime)
    return data_list

            # sql_insert = 'insert into ctripAI_price_data (hotel_id, baseRoomId, ubt_roomid, roomName, isHourRoom, price, filter_id, CrawlTime) values ("{}","{}","{}","{}","{}","{}","{}","{}")'.format(
            #     hotelid, baseRoomId, ubt_roomid, roomName, isHourRoom, price, filter_id, CrawlTime)
            # cursor.execute(sql_insert)
            # # print("数据已添加")
            # conn.commit()

# 解析酒店房型
def parse_data(res):
    hotel_house_dict = {}
    filterInfo = res.get('filterInfo')
    filterInfo = json.loads(filterInfo)
    for info in filterInfo:
        title = info.get("title")
        if title == "房型":
            subItems = info.get("subItems")
            for item in subItems:
                title = item["title"]
                filterId = item['data']['filterId']

                hotel_house_dict[filterId] = title
            break
    return hotel_house_dict

def getCommentList(hotelId, duid, ticket, proxy):
    # proxies = {
    #     "http": "http://"+proxy,
    #     "https": "http://"+proxy
    #     }
    proxies = proxy
    headers = {
        'Host': 'm.ctrip.com',
        'Connection': 'keep-alive',
        'x-ctx-currency': 'CNY',
        'cookie': 'Union=OUID=mini1005&AllianceID=263528&SID=1105084&SourceID=55555546;DUID=' + duid + ';GUID=52271030210972537185',
        'x-ctx-region': 'CN',
        'content-type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Redmi Note 4 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.99 XWEB/3209 MMWEBSDK/20220204 Mobile Safari/537.36 MMWEBID/2173 MicroMessenger/8.0.20.2100(0x28001439) Process/appbrand1 WeChat/arm64 Weixin NetType/WIFI Language/zh_CN ABI/arm64 MiniProgramEnv/android',
        'duid': duid,
        'Accept-Encoding': 'gzip,compress,br,deflate',
        'x-ctx-locale': 'zh-CN',
        'x-wx-openid': '44c56703-16f5-44b2-a062-d17a346ecaf1',
        'charset': 'utf-8',
        'x-ctx-group': 'ctrip',
        'x-ctx-personal-recommend': '1',
        'Referer': 'https://servicewechat.com/wx0e6ed4f51db9d078/614/page-frame.htm'

    }

    post_data = {"hotelId":hotelId,"pageIndex":1,"pageSize":10,"groupTypeBitMap":3,"needStatisticInfo":1,"order":0,"travelType":-1,"tagId":0,"repeatComment":1,"session":{"key":"592c0cf61e91118c683b5be21b495c7b238ac8a28bc51a17cbab54d0ce308018","sessionKey":"076492d2-a06d-4adf-bb9d-939f479ee353"},"head":{"cid":"52271030210972537185","ctok":"","cver":"1.1.135","lang":"01","sid":"","syscode":"30","auth":f"{ticket}","sauth":"","extension":[{"name":"sdkversion","value":"2.23.4"},{"name":"openid","value":"44c56703-16f5-44b2-a062-d17a346ecaf1"},{"name":"pageid","value":"10320654892"},{"name":"supportWebP","value":"true"},{"name":"ubt","value":"{\"vid\":\"1648713663812.ph0d6u\",\"sid\":5,\"pvid\":82,\"ts\":1658234196073,\"create\":1648713663812,\"pid\":\"10650012159\"}"},{"name":"appId","value":"wx0e6ed4f51db9d078"},{"name":"scene","value":"1006"}]}}

    res_json = requests.post(url='https://m.ctrip.com/restapi/soa2/14605/gethotelcomment?_fxpcqlniredt=52271030210972537185',
                            data=json.dumps(post_data, ensure_ascii=False), headers=headers, proxies=proxies).text
    res_json = json.loads(res_json)
    othersCommentList = res_json.get("othersCommentList")
    statisticInfo = res_json.get('statisticInfo')

    # 解析,格式化要返回得数据
    # 1.正常返回， 2.酒店售完没有任何房型，返回空字典{} 3，账号被封返回状态码203   4.登录过期返回状态码201
    if othersCommentList:
        return othersCommentList, statisticInfo
    # elif result == 0 and subRoomMap == {}:
    #     return '空字典'
    elif othersCommentList is None:
        return "ERROR"  # 号被封了
    # elif oth is None:
    #     return "重新登录"

if __name__ == '__main__':
    certificateCode = userValidateNoRisk("0957336922664798B589F547F9BE2F11","hk520366")
    loguru.logger.success("certificateCode:"+str(certificateCode))
    login_parm = userLogin(certificateCode)
    loguru.logger.success("logpin_parm:"+str(login_parm))
    ticket = login_parm[0]
    duid = ticket[1]
    subRoomMap = getroomlist(1641915,duid,ticket)
