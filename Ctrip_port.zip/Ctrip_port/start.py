'''
Author: wangjin
Date: 2022-06-09 13:53:04
LastEditors: wangjin
LastEditTime: 2022-06-13 14:01:15
Description: 
'''
import loguru
import sys,os
import time
from apscheduler.schedulers.blocking import BlockingScheduler
def start():
    loguru.logger.success("开启进程，第一个传参为开启的进程数")
    run_times = int(sys.argv[1])
    times = time.strftime("%Y-%m-%d_%H:%M:%S", time.localtime())
    with open("httpserver.pid","w",encoding="utf-8") as fp:
            fp.write("")
    

    for i in range(1,run_times+1):
        file_name = "log/"+str(i)+"_"+times
        commend = 'nohup python3 Ctrip_main.py 1>'+file_name+' 2>'+file_name+" & echo $! "+file_name+" >> httpserver.pid"
        loguru.logger.success(commend)
        os.system(commend)
        time.sleep(1)

def Monitor():
        scheduler = BlockingScheduler()
        scheduler.add_job (start, "cron" , hour = 16, minute = 5)
        scheduler.add_job (start, "cron" , hour = 17, minute = 10)
        scheduler.start()

if __name__ == '__main__':
    Monitor()
    
        

    
    

