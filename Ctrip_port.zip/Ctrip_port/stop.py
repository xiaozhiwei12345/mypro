'''
Author: wangjin
Date: 2022-06-09 14:47:25
LastEditors: wangjin
LastEditTime: 2022-06-09 14:52:11
Description: 
'''
import loguru
import sys,os
import time

if __name__ == '__main__':
    loguru.logger.success("关闭进程")
    with open("./httpserver.pid","r",encoding="utf-8") as fp:
        res = fp.read()
    for i in res.split("\n")[0:-1]:
        pid = i.split(' ')[0]
        pocess_name = i.split(' ')[1]
        commend = "kill -9 "+pid
        os.system(commend)
        loguru.logger.success(commend + "\t"+pocess_name)