
'''
Author: wangjin
Date: 2022-06-06 17:21:15
LastEditors: wangjin
LastEditTime: 2022-07-01 10:25:19
Description: 即时爬取redis队列中的任务,校正价格变动
'''
from function import Ctrip_page_func
from function import Ctrip_sql_func
from Ctrip_port.tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options 
import requests
import time
import loguru
import json
from log_func import log_fun
import redis


class Ctrip():
    redis_cli = redis.StrictRedis(
        host="redis1.whalepms.com", port=6379, password="zUy0piREyUo", decode_responses=True)
    # 分组使用账号
    group_id = 1

    def Batch(self):
        
        option = Ctrip_options.Options_class()

        # 循环获取任务，一直监控
        while True:
            # 获取任务列表
            Hotel_dicts = Ctrip_sql_func.Get_hotel_json_redis_contab(option.Get_HotelPrice_ids_task)

            # 获取测单任务
            checek_hotel_task_list = self.redis_cli.lpop('Ctrip_task_test_order')
            loguru.logger.info("**************************获取测单任务")
            loguru.logger.info(checek_hotel_task_list)
            if checek_hotel_task_list:
                checek_hotel_task = checek_hotel_task_list.replace("'", '"')
                checek_hotel_task = json.loads(checek_hotel_task)
                hotel_task_list = []
                hotel_task_list.append(checek_hotel_task)
            else:
                hotel_task_list = []

            # 合并任务
            hotel_dict_list = Hotel_dicts + hotel_task_list

            # 如果有任务，遍历列表
            if hotel_dict_list:
                loguru.logger.info("******************************************************五分钟之后的任务")
                loguru.logger.info(hotel_dict_list)

                # 先获取ip多个请求使用一个ip充分利用资源
                ip = self.Get_ip()
                #
                for Hotel_dict in hotel_dict_list:

                    # 获取账号
                    Login_Option = Ctrip_sql_func.Get_usable_login_option(option.DATA_SQL_CONF, If_random=False,group_id=self.group_id)
                    if Login_Option is None:  # 无可用账号时，跳出
                        break

                    loguru.logger.success("待爬取:"+json.dumps(Hotel_dict, ensure_ascii=False))
                    Hotel_id = Hotel_dict["masterHotelId"]
                    room_list = Hotel_dict["roomList"]
                    masterHotelName = Hotel_dict["masterHotelName"]
                    try:
                        HotelData_Dict = Ctrip_page_func.getroomlist(
                            Hotel_id,
                            Login_Option["duid"],
                            Login_Option["ticket"],
                            masterHotelName,
                            proxy=ip
                        )
                        # print(HotelData_Dict)
                    except Exception:
                        # 任务请求失败重新推到redis
                        hotel_dict_list.append(Hotel_dict)
                        Ctrip_sql_func.push_hotel_json_redis_contab(option.Get_HotelPrice_ids_task,Hotel_dict)
                        loguru.logger.error("IP失效，重新更换")
                        ip = self.Get_ip()
                        continue
                    if HotelData_Dict == "ERROR":
                        # 账号被封
                        Ctrip_sql_func.Update_account_state(option.DATA_SQL_CONF, Login_Option["id"],2)
                        loguru.logger.error("账号已被封禁:"+json.dumps(Login_Option, ensure_ascii=False))
                        log_fun.Logger_info(False, data="账号已被封禁:"+json.dumps(Login_Option, ensure_ascii=False))
                        # 账号被封任务重新推到redis
                        hotel_dict_list.append(Hotel_dict)
                        # Ctrip_sql_func.push_hotel_json_redis_contab(option.Get_HotelPrice_ids_task,Hotel_dict)

                        continue
                    elif HotelData_Dict == "空字典":
                        continue
                    elif HotelData_Dict == "重新登录":
                        # 账号登陆信息失效，重新获取登陆状态
                        Login_Option = self.Formate_account(Login_Option,ip,option)
                        HotelData_Dict = Ctrip_page_func.getroomlist(Hotel_id,Login_Option["duid"],Login_Option["ticket"],masterHotelName,proxy=ip)
                        if isinstance(HotelData_Dict, str):
                            loguru.logger.info("再次请求的结果************{}".format(HotelData_Dict))
                            # 二次请求失败任务重新推到redis
                            hotel_dict_list.append(Hotel_dict)
                            # Ctrip_sql_func.push_hotel_json_redis_contab(option.Get_HotelPrice_ids_task, Hotel_dict)
                            time.sleep(10)
                            continue

                    Ctrip_sql_func.Save_hotelPrice_lowest(HotelData_Dict=HotelData_Dict,Room_list=room_list)
                    cooling_time = option.COOL_TIME  # 访问时间修改这里,方式携程大数据风控
                    loguru.logger.info("等待时间："+str(cooling_time))
                    time.sleep(cooling_time)

                loguru.logger.info("再等待时间：" + str(300) + "重新获取任务")
                time.sleep(30)
            # 没有任务，等待
            else:
                loguru.logger.info("没有任务再等待")
                cooling_time = 30  # 访问时间修改这里,方式携程大数据风控
                loguru.logger.info("等待时间："+str(cooling_time))
                time.sleep(cooling_time)

    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip_json = ipFun.get_ip()
        ip = ip_json["Data"][0]["host"]
        loguru.logger.success("获取ip:" + ip)
        while True:
            try:
                key = 'C20A113E'
                passwd = '83425B8FC62D'
                proxy = 'http://{}:{}@{}'.format(key, passwd, ip)
                proxies = {
                    "http": proxy,
                    "https": proxy
                }
                requests.get("http://www.cip.cc", proxies=proxies, verify=False)
                break
            except:
                loguru.logger.info("ip失效:" + ip)
                ip_json = ipFun.get_ip()
                ip = ip_json["Data"][0]["host"]
                continue
        return proxies

    def Formate_account(self,Login_Option,ip,option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''        
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"],Login_Option["password"],ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF,Login_Option["username"],Login_Option["ticket"],Login_Option["duid"])
        return Login_Option


if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()
    # ctrip.Get_ip()


