# coding=utf-8

from function import Ctrip_page_func
from function import Ctrip_sql_func
from Ctrip_port.tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options 
import requests
import time
import loguru
import json
from log_func import log_fun
from apscheduler.schedulers.blocking import BlockingScheduler


class Ctrip():

    group_id = 9

    def Batch(self):
        
        option = Ctrip_options.Options_class()
        # 获取要爬得酒店任务，后端接口拉取数据
        res_data = requests.get("http://172.17.1.48:8080/ota/getHotelInfos").text
        hotel_dicts = json.loads(res_data)
        # 每个任务间隔时间，五十分钟 3000秒保证爬完一次完整任务
        cooling_time = int(3000/len(hotel_dicts))
        loguru.logger.info("总酒店数为:"+str(len(hotel_dicts))+" 计算冷却时间为:"+str(cooling_time))

        # 获取ip
        ip = self.Get_ip()
        for Hotel_dict in hotel_dicts:
            # 获取账号
            login_account = Ctrip_sql_func.Get_usable_login_option(
                option.DATA_SQL_CONF,
                If_random=True,
                group_id=self.group_id
            )
            if login_account is None:
                break

            loguru.logger.success("待爬取:"+json.dumps(Hotel_dict, ensure_ascii=False))
            # 任务酒店id
            Hotel_id = Hotel_dict["masterHotelId"]
            # 任务酒店房型
            room_list = Hotel_dict["roomList"]
            # 任务酒店名称
            masterHotelName = Hotel_dict["masterHotelName"]
            try:
                HotelData_Dict = Ctrip_page_func.getroomlist(
                    Hotel_id,
                    login_account["duid"],
                    login_account["ticket"],
                    masterHotelName,
                    proxy=ip
                )
            except:
                hotel_dicts.append(Hotel_dict)
                loguru.logger.error("IP失效，重新更换")
                ip = self.Get_ip()
                continue
            if HotelData_Dict == "ERROR":
                # 数据封禁账号状态
                Ctrip_sql_func.Update_account_state(option.DATA_SQL_CONF,login_account["id"],2)
                loguru.logger.error("账号已被封禁:"+json.dumps(login_account,ensure_ascii=False))
                log_fun.Logger_info(False,data="账号已被封禁:"+json.dumps(login_account,ensure_ascii=False))
                hotel_dicts.append(Hotel_dict)
                continue
            elif HotelData_Dict == "空字典":
                continue
            elif HotelData_Dict == "重新登录":
                # 账号登陆信息失效，重新获取登陆状态
                Login_Option = self.Formate_account(login_account,ip,option)
                HotelData_Dict = Ctrip_page_func.getroomlist(Hotel_id,Login_Option["duid"],Login_Option["ticket"],masterHotelName,proxy=ip)
            Ctrip_sql_func.Save_hotelPrice_lowest(HotelData_Dict=HotelData_Dict,Room_list=room_list)          
            cooling_time = cooling_time  # 访问时间修改这里,方式携程大数据风控
            loguru.logger.info("等待时间："+str(cooling_time))
            time.sleep(cooling_time)
        
    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip = ipFun.Get_ip()
        ip = ip["Data"][0]["host"]
        loguru.logger.success("获取ip:"+ip)
        while (True):
            try:
                key = '6WHNRXOL'
                passwd = '19B010B528F6'
                proxy = 'http://{}:{}@{}'.format(key, passwd, ip)
                proxies = {
                "http": proxy,
                "https": proxy
                }
                requests.get("http://www.cip.cc", proxies=proxies, verify=False)
                break
            except:
                loguru.logger.info("ip失效:"+ip)
                ip = self.Get_ip()
                continue
        return proxies
    def Formate_account(self,Login_Option,ip,option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''        
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"],Login_Option["password"],ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF,Login_Option["username"],Login_Option["ticket"],Login_Option["duid"])
        return Login_Option

    def Monitor(self):
        scheduler = BlockingScheduler()
        # scheduler.add_job (self.Batch, "cron" , hour = 7, minute = 0)
        scheduler.add_job (self.Batch, "cron" , hour = 8, minute = 30)
        scheduler.add_job (self.Batch, "cron" , hour = 12, minute = 10)
        scheduler.add_job (self.Batch, "cron" , hour = 16, minute = 10)
        scheduler.add_job (self.Batch, "cron" , hour = 18, minute = 10)
        scheduler.add_job (self.Batch, "cron" , hour = 19, minute = 10)
        scheduler.add_job (self.Batch, "cron" , hour = 21, minute = 10)
        scheduler.start()



if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()
    # ctrip.Monitor()


