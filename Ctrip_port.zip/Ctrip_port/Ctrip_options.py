'''
Author: wangjin
Date: 2022-02-25 13:23:41
LastEditTime: 2022-07-01 10:25:44
LastEditors: wangjin
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /ctrip_selenuim_test/Ctrip_options.py
'''
import loguru
# from Ctrip_port.tools.Ip_proxy_tools import create_proxy_auth_extension


class Options_class():
    RunEnv = "DEV"
    TaskName = "开发上线622"
    COOL_TIME = 5 #TODO 暂且用于actual的冷却时间
    group_id = 1
    LOG_SQL_CONF = None
    DATA_SQL_CONF = None
    Redis_host = None
    Get_HotelPrice_ids_task = "Ctrip_task" # 存储待爬取的目标酒店轮询任务列表
    Get_HotelShow_ids_task = "Ctrip_price_appear"#存储待爬取价格是否露出的轮询任务列表
    Get_HotelPrice_ids_task_contab = "Ctrip_task_contab"

    DEV_SQL_CONF_CRALWER = { 
            "HOST":"172.17.1.133",
            "USERNAME":"cralwer",
            "PASSWD":"n3XTPkxKrfM6MSMf",
            "DATABASE":"cralwer"
    }
    PUB_SQL_CONF_CRALWER = {
            "HOST":"172.17.1.154",
            "USERNAME":"crlawer",
            "PASSWD":"4mxzwi7z2RMZLKDm",
            "DATABASE":"crlawer"
            }
    Redis_host_dev = "172.17.1.133"  # 连接的Redis host
    Redis_host_pub = "172.17.1.154" 

    def __init__(self):

        if self.RunEnv == "DEV":
            self.LOG_SQL_CONF = self.DEV_SQL_CONF_CRALWER
            self.DATA_SQL_CONF = self.DEV_SQL_CONF_CRALWER
        if self.RunEnv == "PUB":
            self.LOG_SQL_CONF = self.PUB_SQL_CONF_CRALWER
            self.DATA_SQL_CONF = self.PUB_SQL_CONF_CRALWER



