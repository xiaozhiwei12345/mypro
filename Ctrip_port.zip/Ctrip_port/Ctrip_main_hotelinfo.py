# coding=utf-8

"""
@ProjectName:LuoJinSpiderProject
@Author:月下谁人
@FileName:Ctrip_main_AIhotel.py
@Date:2022/7/18
"""

import re
import pandas
from function import Ctrip_page_func
from function import Ctrip_sql_func
from Ctrip_port.tools.Ip_proxy_tools import fun as ip_fun
import Ctrip_options
import requests
import time
import loguru
import json
import pymysql
# conn = pymysql.connect(host='127.0.0.1', user='root', password="123456", database='zhongyi', port=3306)
conn = pymysql.connect(host='172.17.0.191', user='spider_writer', password="@Uh5vIwhRd3!", database='boss', port=3306)

cursor = conn.cursor()


class Ctrip():
    def Batch(self):

        option = Ctrip_options.Options_class()

        # 获取携程酒店id任务列表
        res_data = requests.get("http://kong.whalepms.com:8000/admincenter/no-token/getHotelAiCtripIds").text
        res_data = json.loads(res_data)
        hotel_list = res_data['result']
        loguru.logger.success("成功获取任务: ")
        loguru.logger.success(hotel_list)

        # 获取ip
        ip = self.Get_ip()

        for hotel_id in hotel_list:
            loguru.logger.success("待爬取: " + str(hotel_id))

            try:
                res = requests.get(
                    url=f'https://hotels.ctrip.com/hotels/detail/?hotelId={hotel_id}',
                    headers={
                        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.47'
                    },
                    proxies=ip,
                   )

                init_data = re.search(pattern=r'window.IBU_HOTEL=({.*?});', string=res.text)
                # print(init_data)

            except:
                # 任务请求失败，重新追加到任务列表
                hotel_list.append(hotel_id)
                loguru.logger.error("IP失效，重新更换")
                ip = self.Get_ip()
                continue

            if init_data:
                # 内置数据
                init_data = init_data.group(1)
                init_data = json.loads(init_data)
                # 酒店名称
                hotel_name = init_data['initData']['base']['hotelName']
                # 酒店ID
                hotel_id = init_data['initData']['base']['masterHotelId']
                # 酒店星级
                hotel_star = init_data['initData']['base']['star']
                # 酒店地址
                hotel_address = init_data['initData']['position']['address']

                # 酒店开业时间, 装修时间， 客房数和联系方式
                label = init_data['initData']['staticHotelInfo']['hotelInfo']['basic']['label']
                # print(label)

                label_dict = {}
                for element in label:
                    if '开业' in element:
                        hotel_opening_time = element.strip('开业：')
                        label_dict['hotel_opening_time'] = hotel_opening_time
                    if '装修时间' in element:
                        hotel_decoration_time = element.strip('装修时间：')
                        label_dict['hotel_decoration_time'] = hotel_decoration_time
                    if '联系方式' in element:
                        hotel_phone = element.strip('联系方式：')
                        label_dict['hotel_phone'] = hotel_phone
                    if '客房数' in element:
                        hotel_rooms_number = element.strip('客房数：')
                        label_dict['hotel_rooms_number'] = hotel_rooms_number

                # 酒店描述
                hotel_description = init_data['initData']['staticHotelInfo']['hotelInfo']['basic']['description']
                # 酒店照片
                hotel_image = init_data['initData']['staticHotelInfo']['hotelInfo']['basic']['image']

                d = {
                    "hotel_id": str(hotel_id),
                    "hotel_name": hotel_name,
                    "hotel_opening_time": label_dict.get('hotel_opening_time'),
                    "hotel_decoration_time": label_dict.get('hotel_decoration_time'),
                    "hotel_rooms_number": label_dict.get('hotel_rooms_number'),
                    "hotel_phone": label_dict.get('hotel_phone'),
                    "hotel_star": hotel_star,
                    'hotel_address': hotel_address,
                    'hotel_description': hotel_description,
                    'hotel_image': hotel_image
                }
                print(d)
                hotel_info = json.dumps(d, ensure_ascii=False)
                print(hotel_info)
                hotel_id = hotel_id
                CrawlTime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                sql_insert = 'insert into hotel_ai_ota_hotel_info (ctrip_id, hotel_info, created_at) values ("{}","{}","{}")'.format(
                    hotel_id, pymysql.escape_string(hotel_info), CrawlTime)
                loguru.logger.success(f"执行sql: {sql_insert}")
                cursor.execute(sql_insert)
                print("数据已添加")
                conn.commit()

            else:
                hotel_list.append(hotel_id)
                continue

            cooling_time = 5  # 访问时间修改这里,方式携程大数据风控
            loguru.logger.info("等待时间：" + str(cooling_time))
            time.sleep(cooling_time)


    def Get_ip(self):
        ipFun = ip_fun.Ip_fun()
        ip_json = ipFun.get_ip()
        ip = ip_json["Data"][0]["host"]
        loguru.logger.success("获取ip:" + ip)
        while True:
            try:
                key = 'C20A113E'
                passwd = '83425B8FC62D'
                proxy = 'http://{}:{}@{}'.format(key, passwd, ip)
                proxies = {
                    "http": proxy,
                    "https": proxy
                }
                requests.get("http://www.cip.cc", proxies=proxies, verify=False)
                break
            except:
                loguru.logger.info("ip失效:" + ip)
                ip_json = ipFun.get_ip()
                ip = ip_json["Data"][0]["host"]
                continue
        return proxies

    def Formate_account(self, Login_Option, ip, option):
        '''
        description: 获取账号的登录信息，并保存到数据库
        return {*}
        '''
        ticket_duid = Ctrip_page_func.Get_ticket_duid(Login_Option["username"], Login_Option["password"], ip)
        Login_Option["ticket"] = ticket_duid[0]
        Login_Option["duid"] = ticket_duid[1]
        Ctrip_sql_func.Save_ticket_duid(option.DATA_SQL_CONF, Login_Option["username"], Login_Option["ticket"],
                                        Login_Option["duid"])
        return Login_Option


if __name__ == '__main__':
    ctrip = Ctrip()
    ctrip.Batch()
    cursor.close()
    conn.close()



